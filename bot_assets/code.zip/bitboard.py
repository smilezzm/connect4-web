"""Compact Connect Four rules; the public array rules remain independent."""
import numpy as np

BOTTOM = sum(1 << (7*c) for c in range(7))
BOARD = sum(63 << (7*c) for c in range(7))
ORDER = (3, 2, 4, 1, 5, 0, 6)
SHIFTS = np.array([7*c + 5-r for r in range(6) for c in range(7)], dtype=np.uint64)

def four(p):
    for s in (1, 7, 6, 8):
        q = p & (p >> s)
        if q & (q >> (2*s)):
            return True
    return False

def possible(mask):
    return (mask + BOTTOM) & BOARD

def winning(p, mask):
    result = (p << 1) & (p << 2) & (p << 3)
    for s in (7, 6, 8):
        q = (p << s) & (p << (2*s))
        result |= q & ((p << (3*s)) | (p >> s))
        q = (p >> s) & (p >> (2*s))
        result |= q & ((p << s) | (p >> (3*s)))
    return result & BOARD & ~mask

def nonlosing(own, mask):
    moves = possible(mask)
    threats = winning(own ^ mask, mask)
    forced = moves & threats
    if forced:
        if forced & (forced-1):
            return 0
        moves = forced
    return moves & ~(threats >> 1)

def mirror(bits):
    result = 0
    for c in range(7):
        result |= ((bits >> (7*c)) & 127) << (7*(6-c))
    return result

def canonical(own, mask):
    a, b = mirror(own), mirror(mask)
    return ((a, b), True) if (b, a) < (mask, own) else ((own, mask), False)

def from_board(board, player):
    own = mask = 0
    for r, c in zip(*np.nonzero(board)):
        bit = 1 << (7*int(c)+5-int(r))
        mask |= bit
        if board[r,c] == player:
            own |= bit
    return own, mask

def to_board(own, mask, player=1):
    a = ((np.uint64(own) >> SHIFTS) & 1).astype(np.int8)
    b = ((np.uint64(mask ^ own) >> SHIFTS) & 1).astype(np.int8)
    return ((a-b)*player).reshape(6,7)

def encode_bits(own, mask):
    a = ((np.uint64(own) >> SHIFTS) & 1).astype(np.float32)
    b = ((np.uint64(mask ^ own) >> SHIFTS) & 1).astype(np.float32)
    return np.stack((a,b,1-a-b)).reshape(3,6,7)

def actions(bits):
    return [c for c in ORDER if bits & (63 << (7*c))]

def drop(mask, col):
    return (mask + (1 << (7*col))) & (63 << (7*col))
