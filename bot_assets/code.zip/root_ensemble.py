"""Use an auxiliary network at the root; leaves retain the fast primary network."""
import torch
from torch import nn

class RootEnsemble(nn.Module):
    def __init__(self,primary,auxiliary,weight=.25):
        super().__init__()
        self.primary=primary
        self.auxiliary=auxiliary
        self.register_buffer("root_weight",torch.tensor(float(weight)))
    def forward(self,states):
        return self.primary(states)
    def evaluate_root(self,states):
        p,v=self.primary(states)
        q,w=self.auxiliary(states)
        return p*(1-self.root_weight)+q*self.root_weight,v*(1-self.root_weight)+w*self.root_weight
