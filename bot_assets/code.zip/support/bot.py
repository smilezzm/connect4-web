"""Platform-compatible CPU bot with persistent bounded search state."""
import json
from pathlib import Path
import numpy as np
import torch
from mcts import search, SearchState
from support.runtime import load_model,set_seed

SIMULATIONS=8192
SYMMETRY=True
MOVE_CPU_SECONDS=.65
MOVE_WALL_SECONDS=1.4
C_PUCT=1.

class Bot:
    def __init__(self,context):
        torch.set_num_threads(1)
        set_seed(context["seed"])
        root=Path(__file__).resolve().parent.parent
        self.model=load_model(root/"models"/"model.pt","cpu")
        path=root/"bot_config.json"
        self.config=json.loads(path.read_text()) if path.exists() else {}
        options={k:self.config[k] for k in ("leaf_batch","proof_fraction","jit","fpu_reduction","proof_order","fast_expand","unique_batch","stop_proven","adaptive_proof","proof_fast","policy_floor","proof_cache","proof_fullsolve","proof_fullsolve_at","proof_policy") if k in self.config}
        options.setdefault("jit",True)
        self.state=SearchState(**options)
        self.state.prepare(self.model)
    def act(self,observation):
        if observation.get("game")!="connect4":
            raise ValueError("only connect4 is supported")
        board=np.asarray(observation["board"],dtype=np.int8)
        if board.shape!=(6,7):
            raise ValueError("board must be 6 by 7")
        legal=observation["legal_actions"]
        counts=search(board,observation["player"],self.model,
              simulations=self.config.get("simulations",SIMULATIONS),
              c_puct=self.config.get("c_puct",C_PUCT),symmetry=True,
              cpu_seconds=MOVE_CPU_SECONDS,wall_seconds=MOVE_WALL_SECONDS,state=self.state)
        if counts.shape!=(7,) or not np.isfinite(counts).all() or np.any(counts<0) or counts.sum()<=0:
            raise ValueError("invalid search output")
        if not legal or any(counts[c]!=0 for c in range(7) if c not in legal):
            raise ValueError("invalid legal actions or counts")
        return int(legal[np.argmax(counts[legal])])
