"""Sound W/D/L intervals: a depth cutoff is unknown, never a draw."""
import time
from bitboard import possible, winning, nonlosing, actions, drop, BOARD

def fast_winning(p,mask):
    result=(p<<1)&(p<<2)&(p<<3)
    left,right=p<<7,p>>7
    result|=(left&(p<<14))&((p<<21)|right)
    result|=(right&(p>>14))&(left|(p>>21))
    left,right=p<<6,p>>6
    result|=(left&(p<<12))&((p<<18)|right)
    result|=(right&(p>>12))&(left|(p>>18))
    left,right=p<<8,p>>8
    result|=(left&(p<<16))&((p<<24)|right)
    result|=(right&(p>>16))&(left|(p>>24))
    return result&BOARD&~mask

class Interrupted(Exception):
    pass

class ProofSearch:
    def __init__(self, capacity=200000, ordering=True,fast=False,cache_depth=False,fullsolve=False,fullsolve_at=18):
        self.fullsolve_at=fullsolve_at
        self.policy={}
        self.fullsolve=fullsolve
        self.cache_depth=cache_depth
        self.depths={}
        self.fast=fast
        self.ordering=ordering
        self.table = {}
        self.capacity = capacity
        self.nodes = 0

    def _put(self, key, lower, upper):
        previous = self.table.get(key, (-1,1))
        bounds = max(previous[0],lower), min(previous[1],upper)
        if bounds[0] > bounds[1]:
            raise AssertionError("inconsistent proof bounds")
        if len(self.table) >= self.capacity:
            self.table.clear()
        if bounds != (-1,1):
            self.table[key] = bounds
        return bounds

    def bounds(self, own, mask, depth, alpha=-1, beta=1, _safe=False):
        self.nodes += 1
        if self.nodes % 64 == 1:
            if self.nodes > self.max_nodes or time.process_time() >= self.cpu_end or time.perf_counter() >= self.wall_end:
                raise Interrupted()
        key = own, mask
        cached = self.table.get(key, (-1,1))
        if cached[0] == cached[1]:
            return cached
        if self.cache_depth and self.depths.get(key,-1)>=depth:
            return cached
        if not (self.fast and _safe) and possible(mask) & (fast_winning(own,mask) if self.fast else winning(own,mask)):
            moves=possible(mask)&(fast_winning(own,mask) if self.fast else winning(own,mask))
            if len(self.policy)>=self.capacity:self.policy.clear()
            self.policy[key]=actions(moves)[0]
            return self._put(key,1,1)
        if mask.bit_count() == 42:
            return self._put(key,0,0)
        if self.fast:
            safe=possible(mask)
            threats=fast_winning(own^mask,mask)
            forced=safe&threats
            if forced:
                if forced&(forced-1):return self._put(key,-1,-1)
                safe=forced
            safe &= ~(threats>>1)
        else:
            safe = nonlosing(own,mask)
        if not safe:
            return self._put(key,-1,-1)
        if depth <= 0:
            return cached
        lower, upper = -1, -1
        complete=True
        ordered = actions(safe)
        if self.ordering and len(ordered)>1 and depth>=3:
            winfn=fast_winning if self.fast else winning
            ordered.sort(key=lambda c:winfn(own|drop(mask,c),mask|drop(mask,c)).bit_count(),reverse=True)
        for i,c in enumerate(ordered):
            bit = drop(mask,c)
            cl,cu = self.bounds(own ^ mask, mask|bit, depth-1, -beta, -max(alpha,lower),True)
            if -cu==1:
                if len(self.policy)>=self.capacity:self.policy.clear()
                self.policy[key]=c
            lower = max(lower,-cu)
            upper = max(upper,-cl)
            if lower >= beta:
                upper = 1 if i+1 < len(ordered) else upper
                complete=i+1==len(ordered)
                break
        if self.cache_depth and complete:
            if len(self.depths)>=self.capacity:self.depths.clear()
            self.depths[key]=max(depth,self.depths.get(key,-1))
        return self._put(key,lower,upper)

    def run(self, root, cpu_end, wall_end, max_nodes=500000):
        self.cpu_end, self.wall_end, self.max_nodes = cpu_end, wall_end, max_nodes
        self.nodes = 0
        remaining = 42-root.mask.bit_count()
        try:
            for depth in ([remaining] if self.fullsolve and remaining<=42-self.fullsolve_at else range(2, remaining+2, 2)):
                for c,child in sorted(root.children.items(), key=lambda item:-item[1].prior):
                    if child.solved is not None:
                        continue
                    lo,hi = self.bounds(child.own, child.mask, min(depth-1,remaining-1),_safe=True)
                    if lo == hi:
                        child.solved = lo
                        if lo==-1:
                            root.refresh()
                            return self.nodes
                root.refresh()
                if root.solved is not None:
                    break
        except Interrupted:
            pass
        root.refresh()
        return self.nodes
