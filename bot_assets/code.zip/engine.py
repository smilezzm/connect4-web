"""Bounded bitboard PUCT, batched inference, exact proofs and tree reuse."""
import math
import time
import numpy as np
import torch
from bitboard import four, possible, winning, nonlosing, actions, drop, canonical, encode_bits, to_board, from_board
from proof import ProofSearch
from inference import compile_inference

class FastNode:
    __slots__ = ("own","mask","player","prior","visits","value_sum","children","solved","pending","initial_value","root_evaluated")
    def __init__(self,own,mask,player,prior=1.):
        self.own,self.mask,self.player,self.prior=own,mask,player,float(prior)
        self.visits=0
        self.value_sum=0.
        self.children={}
        self.solved=None
        self.pending=0
        self.initial_value=0.
        self.root_evaluated=False
    @property
    def board(self):
        return to_board(self.own,self.mask,self.player)
    def mean_value(self,player):
        value=self.value_sum/self.visits if self.visits else 0.
        return value if player==self.player else -value
    def refresh(self):
        if self.children:
            proofs=[c.solved for c in self.children.values()]
            if -1 in proofs:
                self.solved=1
            elif all(p is not None for p in proofs):
                self.solved=max(-p for p in proofs)

class SearchState:
    def __init__(self,cache_size=50000,max_nodes=50000,leaf_batch=8,proof_fraction=.2,jit=False,fpu_reduction=None,proof_order=True,fast_expand=True,unique_batch=True,stop_proven=True,adaptive_proof=False,proof_fast=False,policy_floor=0.,proof_cache=False,proof_fullsolve=False,proof_fullsolve_at=18,proof_policy=False):
        self.proof_policy=proof_policy
        self.policy_floor=policy_floor
        self.adaptive_proof=adaptive_proof
        self.jit=jit
        self.fpu_reduction=fpu_reduction
        self.fast_expand=fast_expand
        self.unique_batch=unique_batch
        self.stop_proven=stop_proven
        self.compiled=None
        self.cache_size,self.max_nodes=cache_size,max_nodes
        self.leaf_batch,self.proof_fraction=leaf_batch,proof_fraction
        self.cache={}
        self.nodes={}
        self.proof=ProofSearch(ordering=proof_order,fast=proof_fast,cache_depth=proof_cache,fullsolve=proof_fullsolve,fullsolve_at=proof_fullsolve_at)
        self.model_token=None
        self.generation=0
        self.stats={}
    def clear(self):
        self.compiled=None
        self.cache.clear()
        self.nodes.clear()
        self.proof.table.clear()
        self.proof.depths.clear()
        self.proof.policy.clear()
        self.model_token=None
        self.generation+=1
    def bind(self,model):
        # Tensor mutation versions catch optimizer steps and load_state_dict.
        token=(id(model),tuple((p.data_ptr(),p._version) for p in tuple(model.parameters())+tuple(model.buffers())))
        if token!=self.model_token:
            self.clear()
            self.model_token=token
    def prepare(self,model):
        self.bind(model)
        if self.jit and next(model.parameters()).device.type=="cpu" and self.compiled is None:
            self.compiled=compile_inference(model)

    def expand(self,node,priors):
        bits=possible(node.mask)
        wins=winning(node.own,node.mask)&bits if self.fast_expand else 0
        safe=nonlosing(node.own,node.mask) if self.fast_expand else bits
        final=node.mask.bit_count()==41
        for c in actions(bits):
            bit=drop(node.mask,c)
            child=FastNode(node.own ^ node.mask,node.mask|bit,-node.player,priors[c])
            if (bool(bit&wins) if self.fast_expand else four(node.own|bit)):
                child.solved=-1
            elif final:
                child.solved=0
            elif (not bool(bit&safe) if self.fast_expand else bool(possible(child.mask)&winning(child.own,child.mask))):
                child.solved=1
            else:
                lo,hi=self.proof.table.get((child.own,child.mask),(-1,1))
                if lo==hi:child.solved=lo
            node.children[c]=child
            self.nodes[(child.own,child.mask,child.player)]=child
        node.refresh()

def run(board,player,model,simulations,c_puct,add_noise,noise_alpha,noise_weight,
        symmetry,cpu_seconds,wall_seconds,state,backup,evaluate_single):
    cpu0,wall0=time.process_time(),time.perf_counter()
    cpu_end=cpu0+cpu_seconds if cpu_seconds is not None else math.inf
    wall_end=wall0+wall_seconds if wall_seconds is not None else math.inf
    def expired():
        return time.process_time()>=cpu_end or time.perf_counter()>=wall_end
    state.bind(model)
    if len(state.nodes)>=state.max_nodes:
        state.nodes.clear()
    own,mask=from_board(board,player)
    root=state.nodes.get((own,mask,player)) if not add_noise else None
    if root is None:
        root=FastNode(own,mask,player)
        state.nodes[(own,mask,player)]=root
    cached_move=state.proof.policy.get((own,mask)) if state.proof_policy and not add_noise else None
    root_survival=actions(nonlosing(own,mask))
    before={c:n.visits for c,n in root.children.items()}
    nn_calls=cache_hits=0
    was_training=model.training
    model.eval()
    device=next(model.parameters()).device

    def evaluate(nodes):
        nonlocal nn_calls,cache_hits
        results={}
        missing={}
        for node in nodes:
            key,reflected=canonical(node.own,node.mask) if symmetry else ((node.own,node.mask),False)
            cache_key=(key,bool(symmetry),bool(node is root and hasattr(model,"evaluate_root")))
            if cache_key in state.cache:
                p,v=state.cache[cache_key]
                results[node]=(p[::-1].copy() if reflected else p.copy(),v)
                cache_hits+=1
            else:
                missing.setdefault(cache_key,[]).append((node,reflected))
        if missing:
            tensors=[]
            keys=list(missing)
            for (a,b),sym,is_root in keys:
                state_array=encode_bits(a,b)
                tensors.append(state_array)
                if symmetry:
                    tensors.append(state_array[:,:,::-1].copy())
            if len(nodes)==1 and not symmetry and state.leaf_batch==1 and not keys[0][2]:
                # Keep the teaching evaluator hook and its terminal contract.
                node=nodes[0]
                p,v=evaluate_single(model,node.board,node.player)
                key,reflected=canonical(node.own,node.mask) if symmetry else ((node.own,node.mask),False)
                entries=[(p[::-1].copy() if reflected else p.copy(),v)]
            else:
                with torch.inference_mode():
                    inputs=torch.from_numpy(np.stack(tensors)).to(device)
                    evaluator=state.compiled if state.compiled is not None else model
                    logits,values=evaluator.evaluate_root(inputs) if keys[0][2] else evaluator(inputs)
                    logits=logits.float().cpu().numpy()
                    values=values.float().cpu().numpy()
                if not np.isfinite(logits).all() or not np.isfinite(values).all():
                    raise ValueError("non-finite network output")
                entries=[]
                for i,((a,b),sym,is_root) in enumerate(keys):
                    if symmetry:
                        scores=(logits[2*i]+logits[2*i+1][::-1])*.5
                        value=float((values[2*i]+values[2*i+1])*.5)
                    else:
                        scores=logits[i]
                        value=float(values[i])
                    p=np.zeros(7,dtype=np.float64)
                    legal=actions(possible(b))
                    scores=scores[legal].astype(np.float64)
                    scores=np.exp(scores-scores.max())
                    p[legal]=scores/scores.sum()
                    entries.append((p,value))
            nn_calls+=1
            if len(state.cache)+len(keys)>state.cache_size:
                state.cache.clear()
            for key,(p,v) in zip(keys,entries):
                state.cache[key]=(p,v)
                for node,reflected in missing[key]:
                    results[node]=(p[::-1].copy() if reflected else p.copy(),v)
        if state.policy_floor:
            for node,(p,v) in list(results.items()):
                legal=actions(possible(node.mask))
                smooth=p*(1-state.policy_floor)
                smooth[legal]+=state.policy_floor/len(legal)
                results[node]=(smooth,v)
        return results

    completed=0
    proof_nodes=0
    try:
        if not root.children:
            if expired() or cached_move is not None:
                priors=np.zeros(7)
                legal=actions(possible(mask))
                priors[legal]=1/len(legal)
            else:
                priors,root.initial_value=evaluate([root])[root]
            state.expand(root,priors)
            before={c:0 for c in root.children}
            root.root_evaluated=True
        elif hasattr(model,"evaluate_root") and not root.root_evaluated and not expired() and cached_move is None:
            priors,root.initial_value=evaluate([root])[root]
            for c,child in root.children.items():child.prior=float(priors[c])
            root.root_evaluated=True
        if cached_move is not None:
            root.children[cached_move].solved=-1
            root.children[cached_move].prior=1.
            root.solved=1
            root.initial_value=1.
        if add_noise:
            legal=list(root.children)
            noise=np.random.dirichlet([noise_alpha]*len(legal))
            for c,n in zip(legal,noise):
                root.children[c].prior=(1-noise_weight)*root.children[c].prior+noise_weight*n
        if state.proof_fraction and not expired() and root.solved is None:
            fraction=state.proof_fraction
            if state.adaptive_proof and len(root_survival)>2:
                fraction*=min(1.,max(.2,(root.mask.bit_count()-8)/16))
            allowance=(cpu_seconds if cpu_seconds is not None else .05)*fraction
            wall_allowance=(wall_seconds if wall_seconds is not None else .1)*fraction
            proof_nodes=state.proof.run(root,min(cpu_end,time.process_time()+allowance),
                                      min(wall_end,time.perf_counter()+wall_allowance))
        while completed<simulations and not expired():
            pending=[]
            reserved=set()
            for _ in range(min(state.leaf_batch,simulations-completed)):
                if expired():
                    break
                node,path=root,[root]
                while node.children and (node is root or node.solved is None):
                    children=list(node.children.values())
                    wins=[c for c in children if c.solved==-1]
                    viable=[c for c in children if c.solved!=1]
                    fallback=[node.children[c] for c in root_survival if c in node.children] if node is root else []
                    children=wins or viable or fallback or children
                    scale=c_puct*math.sqrt(node.visits+node.pending+1)
                    node=max(children,key=lambda c: (-c.solved if c.solved is not None else
                             (c.mean_value(path[-1].player) if c.visits else
                              ((path[-1].mean_value(path[-1].player) if path[-1].visits else path[-1].initial_value)-state.fpu_reduction if state.fpu_reduction is not None else 0.)))+
                             scale*c.prior/(c.visits+c.pending+1)-.25*c.pending)
                    path.append(node)
                if state.unique_batch and node.solved is None and node in reserved:
                    break
                reserved.add(node)
                for n in path:
                    n.pending+=1
                pending.append((node,path))
            if not pending:
                break
            unknown=list(dict.fromkeys(n for n,p in pending if n.solved is None))
            # Return a legal fallback if a tiny deadline expires before inference.
            if unknown and expired():
                for n,path in pending:
                    for p in path:
                        p.pending-=1
                break
            evaluations=evaluate(unknown) if unknown else {}
            for node,path in pending:
                for n in path:
                    n.pending-=1
                if node.solved is None:
                    priors,value=evaluations[node]
                    node.initial_value=value
                    if not node.children:
                        state.expand(node,priors)
                    if node.solved is not None:
                        value=float(node.solved)
                else:
                    value=float(node.solved)
                backup(path,value)
                completed+=1
            if state.stop_proven and root.solved is not None and (cpu_seconds is not None or wall_seconds is not None):
                break
        counts=np.zeros(7,dtype=np.float64)
        wins=[c for c,n in root.children.items() if n.solved==-1]
        viable=[c for c,n in root.children.items() if n.solved!=1]
        allowed=wins or viable or root_survival or list(root.children)
        for c in allowed:
            counts[c]=root.children[c].visits-before.get(c,0)
        if counts.sum()<=0:
            for c in allowed:
                counts[c]=max(root.children[c].prior,1e-12)
        counts*=max(completed,1)/counts.sum()
        state.stats={"completed":completed,"cpu":time.process_time()-cpu0,"wall":time.perf_counter()-wall0,
                     "nn_batches":nn_calls,"cache_hits":cache_hits,"proof_nodes":proof_nodes,
                     "cached_positions":len(state.cache),"tree_nodes":len(state.nodes),"root_proven":root.solved,"compiled_inference":state.compiled is not None,"proof_policy_hit":cached_move is not None}
        return counts
    finally:
        model.train(was_training)
