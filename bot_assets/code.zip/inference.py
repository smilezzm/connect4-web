"""Optional CPU TorchScript inference; checkpoints remain ordinary state dictionaries."""
import torch
import weakref
_CACHE=weakref.WeakKeyDictionary()

def compile_inference(model):
    token=tuple((p.data_ptr(),p._version) for p in tuple(model.parameters())+tuple(model.buffers()))
    cached=_CACHE.get(model)
    if cached is not None and cached[0]==token:return cached[1]
    was_training=model.training
    model.eval()
    try:
        sample=torch.zeros(2,3,6,7,device=next(model.parameters()).device)
        with torch.inference_mode():
            if hasattr(model,"evaluate_root"):
                graph=torch.jit.trace_module(model,{"forward":sample,"evaluate_root":sample},check_trace=False)
                graph=torch.jit.freeze(graph,preserved_attrs=["evaluate_root"])
            else:
                graph=torch.jit.freeze(torch.jit.trace(model,sample,check_trace=False))
            graph(sample)
            if hasattr(graph,"evaluate_root"):graph.evaluate_root(sample)
        _CACHE[model]=(token,graph)
        return graph
    finally:
        model.train(was_training)
