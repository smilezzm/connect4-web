"""Compatible policy/value networks: original MLP, residual MLP and residual CNN."""
import torch
from torch import nn

class Network(nn.Module):
    def __init__(self, architecture="mlp"):
        super().__init__()
        self.architecture=architecture
        if architecture=="mlp":
            self.fc1=nn.Linear(126,128)
            self.fc2=nn.Linear(128,128)
            self.policy=nn.Linear(128,7)
            self.value=nn.Linear(128,1)
        elif architecture=="resmlp":
            self.stem=nn.Linear(126,256)
            self.blocks=nn.ModuleList([nn.Sequential(nn.Linear(256,256),nn.ReLU(),nn.Linear(256,256)) for _ in range(4)])
            self.policy=nn.Linear(256,7)
            self.value=nn.Linear(256,1)
        elif architecture=="cnn":
            self.stem=nn.Conv2d(3,64,3,padding=1,bias=False)
            self.norm=nn.BatchNorm2d(64)
            self.blocks=nn.ModuleList([nn.Sequential(nn.Conv2d(64,64,3,padding=1,bias=False),
                    nn.BatchNorm2d(64),nn.ReLU(),nn.Conv2d(64,64,3,padding=1,bias=False),nn.BatchNorm2d(64)) for _ in range(4)])
            self.policy_conv=nn.Conv2d(64,2,1)
            self.policy=nn.Linear(84,7)
            self.value_conv=nn.Conv2d(64,1,1)
            self.value_fc=nn.Linear(42,64)
            self.value=nn.Linear(64,1)
        else:
            raise ValueError("unknown network architecture")
    def forward(self,x):
        if self.architecture=="mlp":
            x=torch.relu(self.fc1(x.reshape(-1,126)))
            x=torch.relu(self.fc2(x))
            return self.policy(x),torch.tanh(self.value(x)).squeeze(1)
        if self.architecture=="resmlp":
            x=torch.relu(self.stem(x.reshape(-1,126)))
            for block in self.blocks:
                x=torch.relu(x+block(x)*0.5)
            return self.policy(x),torch.tanh(self.value(x)).squeeze(1)
        x=torch.relu(self.norm(self.stem(x)))
        for block in self.blocks:
            x=torch.relu(x+block(x))
        logits=self.policy(torch.relu(self.policy_conv(x)).flatten(1))
        value=self.value(torch.relu(self.value_fc(torch.relu(self.value_conv(x)).flatten(1))))
        return logits,torch.tanh(value).squeeze(1)
