"""PUCT search with exact short tactical proofs; network interface unchanged."""

import math
import time
import numpy as np
import torch

from support.game import legal_moves, next_player, game_result, convert_value, encode
from support.runtime import Node, evaluate_position, root_noise, visit_counts


def select_child(node, c_puct):
    """Prefer proven wins, exclude proven losses, then apply ordinary PUCT."""
    children = list(node.children.values())
    wins = [child for child in children if getattr(child, "solved", None) == -1]
    if wins:
        return max(wins, key=lambda child: child.prior)
    viable = [child for child in children if getattr(child, "solved", None) != 1]
    if viable:
        children = viable
    scale = c_puct * math.sqrt(node.visits + 1)
    best_score, best_child = -math.inf, None
    for child in children:
        solved = getattr(child, "solved", None)
        q = child.mean_value(node.player) if solved is None else -solved
        score = q + scale * child.prior / (child.visits + 1)
        if score > best_score:
            best_score, best_child = score, child
    return best_child


def expand(node, priors):
    """Keep every legal child, attaching only exact win/draw/loss proofs.

    Seven bits per column (six cells plus a sentinel) make the tactical
    checks cheap. A child is a proven loss for its parent if the opponent
    has a legal immediate winning reply. There is no heuristic value bonus.
    """
    def four(bits):
        for shift in (1, 7, 6, 8):
            pairs = bits & (bits >> shift)
            if pairs & (pairs >> (2 * shift)):
                return True
        return False

    if hasattr(node, "bits"):
        own, other, occupied = node.bits
    else:
        own, other = 0, 0
        for row in range(6):
            for col in range(7):
                cell = node.board[row, col]
                bit = 1 << (7 * col + 5 - row)
                if cell == node.player:
                    own |= bit
                elif cell == -node.player:
                    other |= bit
        occupied = own | other
        node.bits = own, other, occupied
    for col in legal_moves(node.board):
        column = 63 << (7 * col)
        move = (occupied + (1 << (7 * col))) & column
        row = 5 - (move.bit_length() - 1 - 7 * col)
        board = node.board.copy()
        board[row, col] = node.player
        child = Node(board, next_player(node.player), priors[col])
        filled = occupied | move
        child.bits = other, own | move, filled
        child.solved = None
        if four(own | move):
            child.solved = -1
        elif filled.bit_count() == 42:
            child.solved = 0
        else:
            for reply in range(7):
                reply_move = (filled + (1 << (7 * reply))) & (63 << (7 * reply))
                if reply_move and four(other | reply_move):
                    child.solved = 1
                    break
        node.children[col] = child
    proofs = [child.solved for child in node.children.values()]
    if -1 in proofs:
        node.solved = 1
    elif proofs and all(value is not None for value in proofs):
        node.solved = max(-value for value in proofs)
    else:
        node.solved = None


def backpropagate(path, value):
    """Back up values and propagate exact minimax proofs separately."""
    leaf_player = path[-1].player
    for node in reversed(path):
        node.value_sum += convert_value(value, leaf_player, node.player)
        node.visits += 1
        if node.children:
            proofs = [getattr(child, "solved", None) for child in node.children.values()]
            if -1 in proofs:
                node.solved = 1
            elif all(proof is not None for proof in proofs):
                node.solved = max(-proof for proof in proofs)



from engine import SearchState, run as run_engine

def search(board, player, model, simulations=32, c_puct=1.0, add_noise=False,
           noise_alpha=0.3, noise_weight=0.25, symmetry=False,
           cpu_seconds=None, wall_seconds=None, state=None,
           leaf_batch=1, proof_fraction=0.0):
    """Seven nonnegative counts; old arguments and helper functions are retained."""
    if simulations < 1:
        raise ValueError("simulations must be positive")
    if cpu_seconds is not None and cpu_seconds <= 0:
        raise ValueError("cpu_seconds must be positive")
    if wall_seconds is not None and wall_seconds <= 0:
        raise ValueError("wall_seconds must be positive")
    if game_result(board)[0]:
        raise ValueError("cannot search a finished game")
    if player not in (-1,1) or np.asarray(board).shape != (6,7):
        raise ValueError("invalid board or player")
    if add_noise and (noise_alpha<=0 or not 0<=noise_weight<=1):
        raise ValueError("invalid root noise")
    if leaf_batch<1 or not 0<=proof_fraction<=1:
        raise ValueError("invalid search configuration")
    context=state if state is not None else SearchState(leaf_batch=leaf_batch,proof_fraction=proof_fraction)
    return run_engine(board,player,model,int(simulations),float(c_puct),add_noise,
                      noise_alpha,noise_weight,symmetry,cpu_seconds,wall_seconds,
                      context,backpropagate,evaluate_position)
